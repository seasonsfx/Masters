now=$(date +"%T")
git add -A
git commit -m "Auto Commit: $now"

make